        // alert( 'Прsfhgsмир!' );
        
      function setOpen(){
        var element = document.getElementById("nav");
        element.classList.add("open");
        setTimeout(setClose, 2000);

      }
      function openNav(){
        setTimeout(setOpen, 1000);
      }
      function setClose(){
        var element2 = document.getElementById("nav");
        element2.classList.remove("open");
      }

      function opentab(event, name){
          var i;
          var tabcont = document.getElementsByClassName("tab-content");
          for(i=0;i<tabcont.length;i++){
              tabcont[i].style.display="none";
          }
          var tablist = document.getElementsByClassName('tablink');
          for(i=0;i<tablist.length; i++){
            tablist[i].className = tablist[i].className.replace(" active", "");
          }
          document.getElementById(name).style.display = "block";
          event.currentTarget.className +=" active";
      }
      
      